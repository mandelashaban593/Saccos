<?php

session_start();


unset($_SESSION['email_stakeholder']);

header("Location:stakeholder-login.php");//use for the redirection to some page




?>