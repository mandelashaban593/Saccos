<?php



if(isset($_POST['stakeholderfname'])){
    echo 'set';
}

else{
    echo 'not set';
}

?>