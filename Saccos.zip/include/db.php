<?php
/*$db=mysqli_connect('localhost','u752865562_sales','"""Look1ng"""','u752865562_sales');*/
//if($db){
//    echo "databse is connected !";
//}else{
//    echo "something is wrong with database !";
//}

$db=mysqli_connect('localhost','root','root','webdynamic');