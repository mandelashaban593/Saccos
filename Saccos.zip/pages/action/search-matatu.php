<?php

$input=$_POST['input'];

echo $input;


?>