<?php



session_start();


unset($_SESSION['email_employee']);

header("Location:../employeepages/employee-login.php");//use for the redirection to some page




?>


