<?php

echo '<table class="table table-hover">
    <thead>
      <tr>
        <th>ID</th>
        <th>Fullname</th>
        <th>Gender</th>
        <th>Id Number</th>
        <th>Phone</th>
        <th>Email</th>
        <th>Password</th>
        <th>Date created</th>
      </tr>
    </thead>';


echo '



    <tbody>
      
      <tr>
        <td>July</td>
        <td>July</td>
        <td>July</td>
        <td>July</td>
        <td>July</td>
        <td>July</td>
        <td>July</td>
        <td>July</td>
      </tr>
  


';

echo '  </tbody>
  </table>';


?>