<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/fancybox/jquery.fancybox.css" rel="stylesheet">
<link href="css/jcarousel.css" rel="stylesheet" />
<link href="css/flexslider.css" rel="stylesheet" />
<link href="js/owl-carousel/owl.carousel.css" rel="stylesheet"> 
<link href="css/style.css" rel="stylesheet" />


<!-- 
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="mycss/mycss.css">
    
 -->
  <!--   <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">

    Nav bar and footer css
    <link rel="stylesheet" href="mycss/styles_footer.css">
    <link rel="stylesheet" href="mycss/styles_navbar.css">

    Navbar and  footer boostrap js -->
  <!--   <script src="pages/navbar.js"></script>
    <script src="https://kit.fontawesome.com/b99e675b6e.js"></script> 

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 -->
