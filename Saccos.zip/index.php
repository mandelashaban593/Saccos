<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>SACCO</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />
<meta name="author" content="http://webthemez.com" />
<!-- css -->
<?php require("style.php"); ?>

<style type="text/css">
    .slides img {
        height: 470px;
        width: 400px;
    }
</style>t
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

</head>
<body>
<div id="wrapper">
<!-- start header -->
<?php require("nav.php"); ?>
<!-- end header -->
<section id="featured" style="height: 300px;">

<!-- Slider -->
<div id="main-slider" class="flexslider" style="height: 300px;">
<ul class="slides">
<li style="height: 300px;">
<img src="img/slides/IMG-20210428-WA0005.jpg" alt="" />
<div class="container"style="height: 300px;" >
<div class="row">
<div class="col-md-12">
<div class="flex-caption" style="height: 300px;">
<h3>Consulting</h3> 
<p>Get to reach us through our contact Page by clicking <a href="contact.php">Contact</a> at any time <br></p>  
</div>
</div></div></div>
</li>
<li style="height: 300px;">
<img src="img/slides/IMG-20210428-WA0005.jpg" alt="" />
<div class="container" style="height: 300px;">
<div class="row">
<div class="col-md-12">
<div class="flex-caption" style="height: 300px;">
<h3>Business</h3> 
<p>A SACCO is an for Savings and Credit Cooperative Organizations. It is owned, governed and managed by its members who have the same common bond: they may be working for the same employer, belonging to the same church, labour union, social fraternity or living/working in the same community.</p> 
</div>
</div></div></div>
</li>
<li style="height: 300px;">
<img src="img/slides/IMG-20210428-WA0006.jpg" alt="" />
<div class="container" style="height: 300px;">
<div class="row">
<div class="col-md-12">
<div class="flex-caption" style="height: 300px;">
<h3>Marketing</h3> 
<p>our marketing strategy we present to our multiple clients, to be process <br/>for managing customer relationships that drive brand value primarily through communication efforts. </p>  
</div>
</div></div></div>
</li>
</ul>
</div>
<!-- end slider -->

</section>
<section class="callaction" style="margin-top:171px;">
<div class="container">
<div class="row">
<div class="col-md-4">
<img src="img/sacc.jpg" alt="" width="100%"/>
</div>
<div class="col-md-8">
<div ><h1><span>BACKGROUND.</h1><span class="clear spacer_responsive_hide_mobile " style="height:13px;display:block;"></span><p>
In recognition of the problems faced in accessing financial services from financial institutions such as banks and other money lending institutions due to rigidity, unfavorable terms and conditions set by these institutions particularly for the rural population and low-income groups such as women, small businesspersons, farmers and even working class and also in realization that people in South Sudan have poor saving habits particularly among the working class. The founding members of Rural-Urban SACCO LTD in a meeting held on 4th March 2013 resolved to establish Rural-Urban SACCO LTD to address the problems faced by people in rural and urban areas in accessing manageable credit facilities and to encourage savings habit among the people in rural and urban areas of South Sudan..</p>
<p></p>
</div>
</div>
</div>

</div>
</section>


<?php require("footer.php"); ?>


</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<?php require("javascripts.php"); ?>



</body	>
</html>