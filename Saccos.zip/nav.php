<header>
<div class="navbar navbar-default navbar-static-top">
<div class="container">
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="index.php"><img src="img/LogoSacc.jpg" alt="logo" style="width:100px;height:85px;border-radius: 10px;" /></a>
</div>
<div class="navbar-collapse collapse ">
<ul class="nav navbar-nav">
<li class="active"><a href="index.php">Home</a></li> 
<li><a href="about.php">About Us</a></li>
<li><a href="services.php">Product & Services</a></li>
<li><a href="portfolio.php">Portfolio</a></li>
<li><a href="governance.php">Governance</a></li>
<li><a href="indrecogn.php">Industry recognition</a></li>

<li><a href="contact.php">Contact</a></li>
<li>
	<li><a href="admin/index.php">Login</a></li>

<div class="dropdown" id="mydropdown">

<!-- <span class="dropdown-menu" id="mydropdown-menu">
<a href="pages/agentpages/home.php">Agent Dashboard</a>
<a href="pages/stakeholderpages/stakeholderhome.php">Stakeholder dashboard</a>
<a href="pages/employeepages/all-matatu.php">Sacco Employee Dashboard</a>
<a href="pages/adminpages/index.php">Admin dashboard</a>
<span class="divider" style="background:#ccc;border:1px solid #ccc;width:100%;"></span>

</span> -->
</div></li>

</ul>

<div class="col-sm-4" id="" style="padding:10px">



</div>
</div>
</div>
</header>