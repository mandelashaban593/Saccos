<?php

$date=Date('d');
$month=Date('M');
$year=Date('Y');
$pref='';




$custom_date=$date. ' ' .$month.' '.$year;







?>